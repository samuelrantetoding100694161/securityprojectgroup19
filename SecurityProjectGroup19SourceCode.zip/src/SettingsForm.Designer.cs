﻿namespace YAPM {
    partial class SettingsForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsForm));
            this.SettingsTimeoutTextbox = new System.Windows.Forms.TextBox();
            this.SettingsTimeoutLabel = new System.Windows.Forms.Label();
            this.SettingsTitleLabel = new System.Windows.Forms.Label();
            this.TimeoutGroupBox = new System.Windows.Forms.GroupBox();
            this.TimeoutCheckBox = new System.Windows.Forms.CheckBox();
            this.MasterPasswordGroupbox = new System.Windows.Forms.GroupBox();
            this.SettingShowPasswordButton = new System.Windows.Forms.Button();
            this.CurrentPasswordLabel = new System.Windows.Forms.Label();
            this.CurrentPasswordTextbox = new System.Windows.Forms.TextBox();
            this.SettingsChangePasswordButton = new System.Windows.Forms.Button();
            this.SettingsPasswordLabel = new System.Windows.Forms.Label();
            this.SettingsPasswordTextbox = new System.Windows.Forms.TextBox();
            this.SettingsConfirmPasswordLabel = new System.Windows.Forms.Label();
            this.SettingsConfirmPasswordTextbox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.HidePasswordsCheckBox = new System.Windows.Forms.CheckBox();
            this.TimeoutGroupBox.SuspendLayout();
            this.MasterPasswordGroupbox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // SettingsTimeoutTextbox
            // 
            this.SettingsTimeoutTextbox.Location = new System.Drawing.Point(17, 100);
            this.SettingsTimeoutTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SettingsTimeoutTextbox.Name = "SettingsTimeoutTextbox";
            this.SettingsTimeoutTextbox.Size = new System.Drawing.Size(288, 26);
            this.SettingsTimeoutTextbox.TabIndex = 2;
            this.SettingsTimeoutTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsTimeoutLabel
            // 
            this.SettingsTimeoutLabel.AutoSize = true;
            this.SettingsTimeoutLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsTimeoutLabel.Location = new System.Drawing.Point(13, 76);
            this.SettingsTimeoutLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SettingsTimeoutLabel.Name = "SettingsTimeoutLabel";
            this.SettingsTimeoutLabel.Size = new System.Drawing.Size(146, 20);
            this.SettingsTimeoutLabel.TabIndex = 20;
            this.SettingsTimeoutLabel.Text = "Timeout time (ms)";
            this.SettingsTimeoutLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsTitleLabel
            // 
            this.SettingsTitleLabel.AutoSize = true;
            this.SettingsTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsTitleLabel.Location = new System.Drawing.Point(16, 16);
            this.SettingsTitleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SettingsTitleLabel.Name = "SettingsTitleLabel";
            this.SettingsTitleLabel.Size = new System.Drawing.Size(100, 29);
            this.SettingsTitleLabel.TabIndex = 22;
            this.SettingsTitleLabel.Text = "Settings";
            this.SettingsTitleLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // TimeoutGroupBox
            // 
            this.TimeoutGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.TimeoutGroupBox.Controls.Add(this.TimeoutCheckBox);
            this.TimeoutGroupBox.Controls.Add(this.SettingsTimeoutLabel);
            this.TimeoutGroupBox.Controls.Add(this.SettingsTimeoutTextbox);
            this.TimeoutGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimeoutGroupBox.Location = new System.Drawing.Point(16, 57);
            this.TimeoutGroupBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TimeoutGroupBox.Name = "TimeoutGroupBox";
            this.TimeoutGroupBox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TimeoutGroupBox.Size = new System.Drawing.Size(391, 150);
            this.TimeoutGroupBox.TabIndex = 23;
            this.TimeoutGroupBox.TabStop = false;
            this.TimeoutGroupBox.Text = "Timeout";
            // 
            // TimeoutCheckBox
            // 
            this.TimeoutCheckBox.AutoSize = true;
            this.TimeoutCheckBox.Location = new System.Drawing.Point(17, 39);
            this.TimeoutCheckBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.TimeoutCheckBox.Name = "TimeoutCheckBox";
            this.TimeoutCheckBox.Size = new System.Drawing.Size(91, 24);
            this.TimeoutCheckBox.TabIndex = 1;
            this.TimeoutCheckBox.Text = "Timeout";
            this.TimeoutCheckBox.UseVisualStyleBackColor = true;
            this.TimeoutCheckBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // MasterPasswordGroupbox
            // 
            this.MasterPasswordGroupbox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.MasterPasswordGroupbox.Controls.Add(this.SettingShowPasswordButton);
            this.MasterPasswordGroupbox.Controls.Add(this.CurrentPasswordLabel);
            this.MasterPasswordGroupbox.Controls.Add(this.CurrentPasswordTextbox);
            this.MasterPasswordGroupbox.Controls.Add(this.SettingsChangePasswordButton);
            this.MasterPasswordGroupbox.Controls.Add(this.SettingsPasswordLabel);
            this.MasterPasswordGroupbox.Controls.Add(this.SettingsPasswordTextbox);
            this.MasterPasswordGroupbox.Controls.Add(this.SettingsConfirmPasswordLabel);
            this.MasterPasswordGroupbox.Controls.Add(this.SettingsConfirmPasswordTextbox);
            this.MasterPasswordGroupbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MasterPasswordGroupbox.Location = new System.Drawing.Point(16, 300);
            this.MasterPasswordGroupbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MasterPasswordGroupbox.Name = "MasterPasswordGroupbox";
            this.MasterPasswordGroupbox.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MasterPasswordGroupbox.Size = new System.Drawing.Size(391, 286);
            this.MasterPasswordGroupbox.TabIndex = 24;
            this.MasterPasswordGroupbox.TabStop = false;
            this.MasterPasswordGroupbox.Text = "Change your master password";
            // 
            // SettingShowPasswordButton
            // 
            this.SettingShowPasswordButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SettingShowPasswordButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SettingShowPasswordButton.BackgroundImage")));
            this.SettingShowPasswordButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SettingShowPasswordButton.Location = new System.Drawing.Point(313, 63);
            this.SettingShowPasswordButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SettingShowPasswordButton.Name = "SettingShowPasswordButton";
            this.SettingShowPasswordButton.Size = new System.Drawing.Size(33, 28);
            this.SettingShowPasswordButton.TabIndex = 26;
            this.SettingShowPasswordButton.UseVisualStyleBackColor = true;
            this.SettingShowPasswordButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SettingShowPasswordButton_MouseDown);
            this.SettingShowPasswordButton.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            this.SettingShowPasswordButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.SettingShowPasswordButton_MouseUp);
            // 
            // CurrentPasswordLabel
            // 
            this.CurrentPasswordLabel.AutoSize = true;
            this.CurrentPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CurrentPasswordLabel.Location = new System.Drawing.Point(12, 38);
            this.CurrentPasswordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.CurrentPasswordLabel.Name = "CurrentPasswordLabel";
            this.CurrentPasswordLabel.Size = new System.Drawing.Size(142, 20);
            this.CurrentPasswordLabel.TabIndex = 25;
            this.CurrentPasswordLabel.Text = "Current password";
            this.CurrentPasswordLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // CurrentPasswordTextbox
            // 
            this.CurrentPasswordTextbox.Location = new System.Drawing.Point(16, 63);
            this.CurrentPasswordTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CurrentPasswordTextbox.Name = "CurrentPasswordTextbox";
            this.CurrentPasswordTextbox.Size = new System.Drawing.Size(288, 26);
            this.CurrentPasswordTextbox.TabIndex = 4;
            this.CurrentPasswordTextbox.UseSystemPasswordChar = true;
            this.CurrentPasswordTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsChangePasswordButton
            // 
            this.SettingsChangePasswordButton.Location = new System.Drawing.Point(17, 241);
            this.SettingsChangePasswordButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SettingsChangePasswordButton.Name = "SettingsChangePasswordButton";
            this.SettingsChangePasswordButton.Size = new System.Drawing.Size(100, 28);
            this.SettingsChangePasswordButton.TabIndex = 7;
            this.SettingsChangePasswordButton.Text = "Change";
            this.SettingsChangePasswordButton.UseVisualStyleBackColor = true;
            this.SettingsChangePasswordButton.Click += new System.EventHandler(this.SettingsChangePasswordButton_Click);
            this.SettingsChangePasswordButton.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsPasswordLabel
            // 
            this.SettingsPasswordLabel.AutoSize = true;
            this.SettingsPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsPasswordLabel.Location = new System.Drawing.Point(13, 102);
            this.SettingsPasswordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SettingsPasswordLabel.Name = "SettingsPasswordLabel";
            this.SettingsPasswordLabel.Size = new System.Drawing.Size(119, 20);
            this.SettingsPasswordLabel.TabIndex = 22;
            this.SettingsPasswordLabel.Text = "New password";
            this.SettingsPasswordLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsPasswordTextbox
            // 
            this.SettingsPasswordTextbox.Location = new System.Drawing.Point(17, 127);
            this.SettingsPasswordTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SettingsPasswordTextbox.Name = "SettingsPasswordTextbox";
            this.SettingsPasswordTextbox.Size = new System.Drawing.Size(288, 26);
            this.SettingsPasswordTextbox.TabIndex = 5;
            this.SettingsPasswordTextbox.UseSystemPasswordChar = true;
            this.SettingsPasswordTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsConfirmPasswordLabel
            // 
            this.SettingsConfirmPasswordLabel.AutoSize = true;
            this.SettingsConfirmPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SettingsConfirmPasswordLabel.Location = new System.Drawing.Point(13, 169);
            this.SettingsConfirmPasswordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SettingsConfirmPasswordLabel.Name = "SettingsConfirmPasswordLabel";
            this.SettingsConfirmPasswordLabel.Size = new System.Drawing.Size(180, 20);
            this.SettingsConfirmPasswordLabel.TabIndex = 20;
            this.SettingsConfirmPasswordLabel.Text = "Confirm new password";
            this.SettingsConfirmPasswordLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsConfirmPasswordTextbox
            // 
            this.SettingsConfirmPasswordTextbox.Location = new System.Drawing.Point(17, 193);
            this.SettingsConfirmPasswordTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SettingsConfirmPasswordTextbox.Name = "SettingsConfirmPasswordTextbox";
            this.SettingsConfirmPasswordTextbox.Size = new System.Drawing.Size(288, 26);
            this.SettingsConfirmPasswordTextbox.TabIndex = 6;
            this.SettingsConfirmPasswordTextbox.UseSystemPasswordChar = true;
            this.SettingsConfirmPasswordTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.HidePasswordsCheckBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 210);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(391, 85);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Passwords visibility";
            // 
            // HidePasswordsCheckBox
            // 
            this.HidePasswordsCheckBox.AutoSize = true;
            this.HidePasswordsCheckBox.Location = new System.Drawing.Point(17, 39);
            this.HidePasswordsCheckBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.HidePasswordsCheckBox.Name = "HidePasswordsCheckBox";
            this.HidePasswordsCheckBox.Size = new System.Drawing.Size(271, 24);
            this.HidePasswordsCheckBox.TabIndex = 3;
            this.HidePasswordsCheckBox.Text = "Hide passwords when displayed";
            this.HidePasswordsCheckBox.UseVisualStyleBackColor = true;
            this.HidePasswordsCheckBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 601);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.MasterPasswordGroupbox);
            this.Controls.Add(this.TimeoutGroupBox);
            this.Controls.Add(this.SettingsTitleLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SettingsForm";
            this.Text = "Settings";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SettingsForm_FormClosing);
            this.Load += new System.EventHandler(this.SettingsForm_Load);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SettingsForm_MouseMove);
            this.TimeoutGroupBox.ResumeLayout(false);
            this.TimeoutGroupBox.PerformLayout();
            this.MasterPasswordGroupbox.ResumeLayout(false);
            this.MasterPasswordGroupbox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SettingsTimeoutTextbox;
        private System.Windows.Forms.Label SettingsTimeoutLabel;
        private System.Windows.Forms.Label SettingsTitleLabel;
        private System.Windows.Forms.GroupBox TimeoutGroupBox;
        private System.Windows.Forms.CheckBox TimeoutCheckBox;
        private System.Windows.Forms.GroupBox MasterPasswordGroupbox;
        private System.Windows.Forms.Button SettingsChangePasswordButton;
        private System.Windows.Forms.Label SettingsPasswordLabel;
        private System.Windows.Forms.TextBox SettingsPasswordTextbox;
        private System.Windows.Forms.Label SettingsConfirmPasswordLabel;
        private System.Windows.Forms.TextBox SettingsConfirmPasswordTextbox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox HidePasswordsCheckBox;
        private System.Windows.Forms.Label CurrentPasswordLabel;
        private System.Windows.Forms.TextBox CurrentPasswordTextbox;
        private System.Windows.Forms.Button SettingShowPasswordButton;
    }
}