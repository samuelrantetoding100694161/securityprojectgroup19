﻿namespace YAPM {
    partial class EditPasswordEntryForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditPasswordEntryForm));
            this.EditPassWebsiteTextbox = new System.Windows.Forms.TextBox();
            this.EditPassWebsiteLabel = new System.Windows.Forms.Label();
            this.showPasswordButton = new System.Windows.Forms.Button();
            this.SavePasswordButton = new System.Windows.Forms.Button();
            this.EditPassPasswordTextbox = new System.Windows.Forms.TextBox();
            this.EditPassPasswordLabel = new System.Windows.Forms.Label();
            this.EditPassEmailTextbox = new System.Windows.Forms.TextBox();
            this.EditPassEmailLabel = new System.Windows.Forms.Label();
            this.EditPassUsernameTextbox = new System.Windows.Forms.TextBox();
            this.EditPassUsernameLabel = new System.Windows.Forms.Label();
            this.EditPasswordTitleLabel = new System.Windows.Forms.Label();
            this.EditPassNotesLabel = new System.Windows.Forms.Label();
            this.EditPassNotesTextbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // EditPassWebsiteTextbox
            // 
            this.EditPassWebsiteTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassWebsiteTextbox.Location = new System.Drawing.Point(67, 231);
            this.EditPassWebsiteTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditPassWebsiteTextbox.Name = "EditPassWebsiteTextbox";
            this.EditPassWebsiteTextbox.Size = new System.Drawing.Size(327, 22);
            this.EditPassWebsiteTextbox.TabIndex = 16;
            this.EditPassWebsiteTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassWebsiteLabel
            // 
            this.EditPassWebsiteLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassWebsiteLabel.AutoSize = true;
            this.EditPassWebsiteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPassWebsiteLabel.Location = new System.Drawing.Point(63, 206);
            this.EditPassWebsiteLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EditPassWebsiteLabel.Name = "EditPassWebsiteLabel";
            this.EditPassWebsiteLabel.Size = new System.Drawing.Size(78, 24);
            this.EditPassWebsiteLabel.TabIndex = 19;
            this.EditPassWebsiteLabel.Text = "Website";
            this.EditPassWebsiteLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // showPasswordButton
            // 
            this.showPasswordButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.showPasswordButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("showPasswordButton.BackgroundImage")));
            this.showPasswordButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.showPasswordButton.Location = new System.Drawing.Point(399, 294);
            this.showPasswordButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.showPasswordButton.Name = "showPasswordButton";
            this.showPasswordButton.Size = new System.Drawing.Size(31, 25);
            this.showPasswordButton.TabIndex = 18;
            this.showPasswordButton.UseVisualStyleBackColor = true;
            this.showPasswordButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.showPasswordButton_MouseDown);
            this.showPasswordButton.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            this.showPasswordButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.showPasswordButton_MouseUp);
            // 
            // SavePasswordButton
            // 
            this.SavePasswordButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SavePasswordButton.Location = new System.Drawing.Point(127, 482);
            this.SavePasswordButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SavePasswordButton.Name = "SavePasswordButton";
            this.SavePasswordButton.Size = new System.Drawing.Size(203, 37);
            this.SavePasswordButton.TabIndex = 20;
            this.SavePasswordButton.Text = "Save";
            this.SavePasswordButton.UseVisualStyleBackColor = true;
            this.SavePasswordButton.Click += new System.EventHandler(this.SavePasswordButton_Click);
            this.SavePasswordButton.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassPasswordTextbox
            // 
            this.EditPassPasswordTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassPasswordTextbox.Location = new System.Drawing.Point(65, 294);
            this.EditPassPasswordTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditPassPasswordTextbox.Name = "EditPassPasswordTextbox";
            this.EditPassPasswordTextbox.Size = new System.Drawing.Size(327, 22);
            this.EditPassPasswordTextbox.TabIndex = 17;
            this.EditPassPasswordTextbox.UseSystemPasswordChar = true;
            this.EditPassPasswordTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassPasswordLabel
            // 
            this.EditPassPasswordLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassPasswordLabel.AutoSize = true;
            this.EditPassPasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPassPasswordLabel.Location = new System.Drawing.Point(61, 268);
            this.EditPassPasswordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EditPassPasswordLabel.Name = "EditPassPasswordLabel";
            this.EditPassPasswordLabel.Size = new System.Drawing.Size(92, 24);
            this.EditPassPasswordLabel.TabIndex = 15;
            this.EditPassPasswordLabel.Text = "Password";
            this.EditPassPasswordLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassEmailTextbox
            // 
            this.EditPassEmailTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassEmailTextbox.Location = new System.Drawing.Point(64, 165);
            this.EditPassEmailTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditPassEmailTextbox.Name = "EditPassEmailTextbox";
            this.EditPassEmailTextbox.Size = new System.Drawing.Size(327, 22);
            this.EditPassEmailTextbox.TabIndex = 14;
            this.EditPassEmailTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassEmailLabel
            // 
            this.EditPassEmailLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassEmailLabel.AutoSize = true;
            this.EditPassEmailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPassEmailLabel.Location = new System.Drawing.Point(60, 139);
            this.EditPassEmailLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EditPassEmailLabel.Name = "EditPassEmailLabel";
            this.EditPassEmailLabel.Size = new System.Drawing.Size(57, 24);
            this.EditPassEmailLabel.TabIndex = 13;
            this.EditPassEmailLabel.Text = "Email";
            this.EditPassEmailLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassUsernameTextbox
            // 
            this.EditPassUsernameTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassUsernameTextbox.Location = new System.Drawing.Point(65, 97);
            this.EditPassUsernameTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditPassUsernameTextbox.Name = "EditPassUsernameTextbox";
            this.EditPassUsernameTextbox.Size = new System.Drawing.Size(327, 22);
            this.EditPassUsernameTextbox.TabIndex = 12;
            this.EditPassUsernameTextbox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassUsernameLabel
            // 
            this.EditPassUsernameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassUsernameLabel.AutoSize = true;
            this.EditPassUsernameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPassUsernameLabel.Location = new System.Drawing.Point(61, 71);
            this.EditPassUsernameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EditPassUsernameLabel.Name = "EditPassUsernameLabel";
            this.EditPassUsernameLabel.Size = new System.Drawing.Size(97, 24);
            this.EditPassUsernameLabel.TabIndex = 11;
            this.EditPassUsernameLabel.Text = "Username";
            this.EditPassUsernameLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPasswordTitleLabel
            // 
            this.EditPasswordTitleLabel.AutoSize = true;
            this.EditPasswordTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPasswordTitleLabel.Location = new System.Drawing.Point(15, 16);
            this.EditPasswordTitleLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EditPasswordTitleLabel.Name = "EditPasswordTitleLabel";
            this.EditPasswordTitleLabel.Size = new System.Drawing.Size(166, 29);
            this.EditPasswordTitleLabel.TabIndex = 10;
            this.EditPasswordTitleLabel.Text = "Edit password";
            this.EditPasswordTitleLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            // 
            // EditPassNotesLabel
            // 
            this.EditPassNotesLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassNotesLabel.AutoSize = true;
            this.EditPassNotesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditPassNotesLabel.Location = new System.Drawing.Point(61, 330);
            this.EditPassNotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EditPassNotesLabel.Name = "EditPassNotesLabel";
            this.EditPassNotesLabel.Size = new System.Drawing.Size(59, 24);
            this.EditPassNotesLabel.TabIndex = 21;
            this.EditPassNotesLabel.Text = "Notes";
            // 
            // EditPassNotesTextbox
            // 
            this.EditPassNotesTextbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.EditPassNotesTextbox.Location = new System.Drawing.Point(64, 356);
            this.EditPassNotesTextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.EditPassNotesTextbox.Multiline = true;
            this.EditPassNotesTextbox.Name = "EditPassNotesTextbox";
            this.EditPassNotesTextbox.Size = new System.Drawing.Size(327, 96);
            this.EditPassNotesTextbox.TabIndex = 19;
            // 
            // EditPasswordEntryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 554);
            this.Controls.Add(this.EditPassNotesTextbox);
            this.Controls.Add(this.EditPassNotesLabel);
            this.Controls.Add(this.EditPassWebsiteTextbox);
            this.Controls.Add(this.EditPassWebsiteLabel);
            this.Controls.Add(this.showPasswordButton);
            this.Controls.Add(this.SavePasswordButton);
            this.Controls.Add(this.EditPassPasswordTextbox);
            this.Controls.Add(this.EditPassPasswordLabel);
            this.Controls.Add(this.EditPassEmailTextbox);
            this.Controls.Add(this.EditPassEmailLabel);
            this.Controls.Add(this.EditPassUsernameTextbox);
            this.Controls.Add(this.EditPassUsernameLabel);
            this.Controls.Add(this.EditPasswordTitleLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "EditPasswordEntryForm";
            this.Text = "Edit password";
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.EditPasswordEntryForm_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox EditPassWebsiteTextbox;
        private System.Windows.Forms.Label EditPassWebsiteLabel;
        private System.Windows.Forms.Button showPasswordButton;
        private System.Windows.Forms.Button SavePasswordButton;
        private System.Windows.Forms.TextBox EditPassPasswordTextbox;
        private System.Windows.Forms.Label EditPassPasswordLabel;
        private System.Windows.Forms.TextBox EditPassEmailTextbox;
        private System.Windows.Forms.Label EditPassEmailLabel;
        private System.Windows.Forms.TextBox EditPassUsernameTextbox;
        private System.Windows.Forms.Label EditPassUsernameLabel;
        private System.Windows.Forms.Label EditPasswordTitleLabel;
        private System.Windows.Forms.Label EditPassNotesLabel;
        private System.Windows.Forms.TextBox EditPassNotesTextbox;
    }
}