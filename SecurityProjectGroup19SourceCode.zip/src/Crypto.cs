﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using Sodium;
using System.IO;
using System.Windows.Forms;

namespace YAPM {

    // Class to handle the encryption and decryption of the saved password
    class Crypto {
        // Get AppData folder path.
        static string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        static string YAPM_PATH = appdata + "\\YAPM";
        static string YAPM_STORE = appdata + "\\YAPM\\main_store";
        static string YAPM_AUTH = appdata + "\\YAPM\\auth";
        static string YAPM_SETTINGS = appdata + "\\YAPM\\settings";
        static string YAPM_STORE_NONCE = appdata + "\\YAPM\\main_store_nonce";
        static string YAPM_KEY = appdata + "\\YAPM\\enc_key";
        static string YAPM_KEY_NONCE = appdata + "\\YAPM\\enc_key_nonce";
        static TabControl tControl;
        static Button accountLoginButton;

        // Verify that the user has entered the correct master password.
        public static void Authenticate(TextBox passTextBox, Button loginButton, Label statusLabel, Label infoLabel, TabControl tabControl, ListView passwordListView) {
            statusLabel.Text = "Verfiying your master password";
            // Prevent multiple login attempts at once.
            loginButton.Enabled = false;
            tControl = tabControl;
            accountLoginButton = loginButton;
            string masterPassword = passTextBox.Text;
            string masterPasswordHash = File.ReadAllText(YAPM_AUTH);
            // Start a background thread to verify password.
            // Background thread is used due to intensivity of Argon2i.
            new Thread(() => {
            Thread.CurrentThread.IsBackground = true;
            if (PasswordHash.ArgonHashStringVerify(masterPasswordHash, masterPassword)) {
                // Correct master password.
                statusLabel.Invoke((MethodInvoker)(() => statusLabel.Text = ""));
                tabControl.Invoke((MethodInvoker)(() => tabControl.SelectTab(2)));
                passTextBox.Invoke((MethodInvoker)(() => passTextBox.Text = ""));
                PasswordManage pm = new PasswordManage(masterPassword, infoLabel, passwordListView);
            } else {
                // Incorrect master password.
                statusLabel.Invoke((MethodInvoker)(() => statusLabel.Text = "Invalid master password"));
                MessageBox.Show("Invalid master password");
            }
            loginButton.Invoke((MethodInvoker)(() => loginButton.Enabled = true));
            }).Start();
        }

        // Function to generate encryption key for the master password
        private static byte[] GetKey(string masterPassword) {
            // Retrieve encrypted encryption key
            byte[] encKey = Convert.FromBase64String(File.ReadAllText(YAPM_KEY));
            //Retrieve the nonce key for additional safety to mitigate attacks
            byte[] nonceKey = Convert.FromBase64String(File.ReadAllText(YAPM_KEY_NONCE));
            // Decrypt the encryption key with values stored in YAPM folder and it will be in 32 bytes.
            byte[] k = SecretAeadAes.Decrypt(encKey, nonceKey, GenericHash.Hash(masterPassword, (byte[])null, 32));
            return k;
        }

        // Function to retrieve all the contents from main store.
        private static string[] GetStoreFileContents() {
            // Read each line from file. String array contains base64 encoded strings.
            string[] stFContent = File.ReadAllLines(YAPM_STORE);
            return stFContent;
        }

        // Function to retrieve the nonce key for the main store.
        private static byte[] GetNonce() {
            //convert from byte to string
            byte[] nKey = Convert.FromBase64String(File.ReadAllText(YAPM_STORE_NONCE));
            return nKey;//return byte of the nonce key
        }
        
        // Function to initialize the stored twelve bytes nonce key to 0.
        public static void InitialiseNonce() {
            byte[] nonce = new byte[12] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            File.WriteAllText(YAPM_STORE_NONCE, Convert.ToBase64String(nonce));
        }

        //To encrypt the password.
        public static void EncryptStoreFile(string masterPassword, string[] dataToEncrypt) {
            // Get variables needed to encrypt
            byte[] nKey = GetNonce();//retrieve the nonce key
            byte[] masterkey = GetKey(masterPassword);//retrieve the encrypted key of the master password
            // Clear main store as only 1 password can be saved in the master password
            File.WriteAllText(YAPM_STORE, "");
            // Encrypt each password entry.
            for (int i = 0; i < dataToEncrypt.Length; i++) {
                // Increment nonce key so every password entry utilizes a different nonce key
                ByteOperation.Increment(ref nKey);
                byte[] byteDataToEnc = Encoding.ASCII.GetBytes(dataToEncrypt[i]);
                var encrypted = SecretAeadAes.Encrypt(byteDataToEnc, nKey, masterkey);
                File.AppendAllText(YAPM_STORE, Convert.ToBase64String(encrypted) + Environment.NewLine);
            }
            // Write nonce key to master password file.
            File.WriteAllText(YAPM_STORE_NONCE, Convert.ToBase64String(nKey));
        }

        // To decrypt the master password for verification.
        public static List<string> DecryptStoreFile(string masterPassword) {
            // Get the variables needed to decrypt
            string[] sFContent = GetStoreFileContents();
            //get the nonce key
            byte[] nKey = GetNonce();
            //get the key for master password
            byte[] masterkey = GetKey(masterPassword);
            List<string> decList = new List<string>();
            // Decrypt each password entry
            for (int i = sFContent.Length - 1; i > -1; i--) {
                //each encryption data will be decrypt to a string
                byte[] dataToDecrypt = Convert.FromBase64String(sFContent[i]);
                //start decrypting with AES decryption method
                var decrypted = SecretAeadAes.Decrypt(dataToDecrypt, nKey, masterkey);
                //retrieve the decrypted list
                decList.Add(Encoding.ASCII.GetString(decrypted));
                // Decrement nonce key to get each nonce key used to encrypt the saved password
                ByteOperation.Decrement(ref nKey);
            }
            // Return list containing all decrypted password entries.
            return decList;
        }

        // Function to run Argon2i.
        public static string ArgonHash(string masterPassword) {
            return PasswordHash.ArgonHashString(masterPassword, PasswordHash.StrengthArgon.Moderate);
        }

        // Function to generate encryption key.
        public static void GenerateEncryptionKey(string masterPassword) {
            // Generate random 32 byte encryption key, 12 byte random nonce and 32 byte hash to use as key from master password.
            byte[] encryptionKey = SodiumCore.GetRandomBytes(32);
            byte[] nonce = SecretAeadAes.GenerateNonce();
            byte[] key = GenericHash.Hash(masterPassword, (byte[]) null, 32);
            // Encrypt encryption key with master password.
            byte[] encryptedKey = SecretAeadAes.Encrypt(encryptionKey, nonce, key);
            // Store bytes in base64 encoding.
            File.WriteAllText(YAPM_KEY, Convert.ToBase64String(encryptedKey));
            File.WriteAllText(YAPM_KEY_NONCE, Convert.ToBase64String(nonce));
        }

        // Function to change the master password.
        public static void ChangeMasterPassword(string oldMasterPassword, string newMasterPassword) {
            // Get current encryption key.
            byte[] key = GetKey(oldMasterPassword);
            // Re-encrypt key with new master password and store.
            byte[] nonce = SecretAeadAes.GenerateNonce();
            byte[] keyToEncryptKey = GenericHash.Hash(newMasterPassword, (byte[])null, 32);
            byte[] encryptedKey = SecretAeadAes.Encrypt(key, nonce, keyToEncryptKey);
            // Store bytes in base64 encoding.
            File.WriteAllText(YAPM_KEY, Convert.ToBase64String(encryptedKey));
            File.WriteAllText(YAPM_KEY_NONCE, Convert.ToBase64String(nonce));
            // Change authentication hash.
            string newArgonHash = ArgonHash(newMasterPassword);
            File.WriteAllText(YAPM_AUTH, newArgonHash);
        }

        // Lock the application.
        public static void Lock() {
            // Go to login page
            tControl.Invoke((MethodInvoker)(() => tControl.SelectTab(0)));
            // Close open forms.
            if (Application.OpenForms["EditPasswordEntryForm"] != null) {
                Application.OpenForms["EditPasswordEntryForm"].Invoke((MethodInvoker)(() => Application.OpenForms["EditPasswordEntryForm"].Close()));
            }
            if (Application.OpenForms["AddPasswordForm"] != null) {
                Application.OpenForms["AddPasswordForm"].Invoke((MethodInvoker)(() => Application.OpenForms["AddPasswordForm"].Close()));
            }
            // Enable login button.
            accountLoginButton.Invoke((MethodInvoker)(() => accountLoginButton.Enabled = true));
        }
    }
}
