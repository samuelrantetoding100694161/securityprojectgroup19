﻿using System;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace YAPM {

    class Register {
        // Get AppData folder path.
        static string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        static string YAPM_PATH = appdata+ "\\YAPM";
        static string YAPM_STORE = appdata + "\\YAPM\\main_store";
        static string YAPM_AUTH = appdata + "\\YAPM\\auth";
        static string YAPM_SETTINGS = appdata + "\\YAPM\\settings";

        public static void MakeUser(string masterPass, TabControl tabControl, Label statusLabel) {
            statusLabel.Text = "Processing master password";
            CreateFiles(masterPass);
            WriteSettings();
            CreateAuthHash(masterPass, tabControl, statusLabel);
        }

        // Create YAPM directory and store file.
        private static void CreateFiles(string masterPassword) {
            Directory.CreateDirectory(YAPM_PATH);
            File.Create(YAPM_STORE);
        }

        // Create Argon2i hash of master password.
        private static void CreateAuthHash(string masterPassword, TabControl tabControl, Label statusLabel) {
            // Background thread is used due to intensivity of Argon2i.
            new Thread(() => {
                Thread.CurrentThread.IsBackground = true;
                var masterPasswordHash = Crypto.ArgonHash(masterPassword);
                File.WriteAllText(YAPM_AUTH, masterPasswordHash);
                statusLabel.Invoke((MethodInvoker)(() => statusLabel.Text = ""));
                tabControl.Invoke((MethodInvoker)(() => tabControl.SelectTab(0)));
                // Generate the encryption key.
                Crypto.GenerateEncryptionKey(masterPassword);
                Crypto.InitialiseNonce();
            }).Start();
        }

        // Write default configuration to settings file.
        private static void WriteSettings() {
            string defaultConfig = "HidePassword=true" + Environment.NewLine +
                "Timeout=120000" + Environment.NewLine + 
                "TimeoutEnabled=true";
            File.WriteAllText(YAPM_SETTINGS, defaultConfig);
        }
    }
}
