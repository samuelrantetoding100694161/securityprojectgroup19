﻿namespace YAPM {

    class ByteOperation {

        // Increment a byte. This is used for the nonce key
        public static void Increment(ref byte[] byteArr) {
            for (int i = 0; i < byteArr.Length; i++) {//for loop to increment each key according to the length of the byte
                byteArr[i]++;//increment
                if (byteArr[i] > 0) {//as long byte array is not empty
                    return;
                }
            }
            return;
        }

        // Decrement a byte
        public static void Decrement(ref byte[] byteArr) {
            for (int i = 0; i < byteArr.Length; i++) {//for loop to decrement based on the length of the byte
                byteArr[i]--;//decrement
                if (byteArr[i] < 255) {//as long as byte array is not greather than 255 (2 power of 8 -1)
                    return;
                }
            }
            return;
        }
    }
}
